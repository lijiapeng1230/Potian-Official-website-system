<?php
define('IN_ADMIN', true);
require_once '../config/database.php';
require_once '../classes/Auth.php';

$auth = new Auth($pdo);

// 检查是否登录且是管理员
if (!$auth->isLoggedIn() || !$auth->isAdmin()) {
    header('Location: login.php');
    exit;
}

// 获取当前页面
$page = $_GET['page'] ?? 'dashboard';

// 获取基础统计数据
$totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$totalVipUsers = $pdo->query("SELECT COUNT(*) FROM users WHERE is_vip = 1")->fetchColumn();
$totalDownloads = $pdo->query("SELECT COUNT(*) FROM download_stats")->fetchColumn();
$newUsersToday = $pdo->query("SELECT COUNT(*) FROM users WHERE DATE(created_at) = CURDATE()")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理后台 - 破天星辰科技网络</title>
    <link href="https://cdn.bootcdn.net/ajax/libs/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.bootcdn.net/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0f2f5;
        }
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: 250px;
            background: #001529;
            color: #fff;
            padding-top: 20px;
        }
        .sidebar .nav-link {
            color: #fff;
            padding: 10px 20px;
            margin: 5px 0;
        }
        .sidebar .nav-link:hover {
            background: #1890ff;
        }
        .sidebar .nav-link i {
            margin-right: 10px;
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
        }
        .top-bar {
            background: #fff;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .stat-card {
            background: #fff;
            border-radius: 5px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .stat-card i {
            font-size: 2em;
            margin-bottom: 10px;
            color: #1890ff;
        }
        .quick-actions {
            background: #fff;
            border-radius: 5px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .action-btn {
            padding: 10px;
            border: none;
            border-radius: 5px;
            background: #f5f5f5;
            margin: 5px;
            transition: all 0.3s;
        }
        .action-btn:hover {
            background: #1890ff;
            color: #fff;
        }
    </style>
</head>
<body>
    <!-- 侧边栏 -->
    <div class="sidebar">
        <h4 class="text-center mb-4">管理后台</h4>
        <nav class="nav flex-column">
            <a class="nav-link <?php echo $page === 'dashboard' ? 'active' : ''; ?>" href="?page=dashboard">
                <i class="fas fa-home"></i> 控制台
            </a>
            <a class="nav-link <?php echo $page === 'users' ? 'active' : ''; ?>" href="?page=users">
                <i class="fas fa-users"></i> 用户管理
            </a>
            <a class="nav-link <?php echo $page === 'statistics' ? 'active' : ''; ?>" href="?page=statistics">
                <i class="fas fa-chart-bar"></i> 数据统计
            </a>
            <a class="nav-link <?php echo $page === 'settings' ? 'active' : ''; ?>" href="?page=settings">
                <i class="fas fa-cog"></i> 系统设置
            </a>
            <a class="nav-link <?php echo $page === 'logs' ? 'active' : ''; ?>" href="?page=logs">
                <i class="fas fa-history"></i> 操作日志
            </a>
            <a class="nav-link" href="../">
                <i class="fas fa-arrow-left"></i> 返回前台
            </a>
            <a class="nav-link" href="../logout.php">
                <i class="fas fa-sign-out-alt"></i> 退出登录
            </a>
        </nav>
    </div>

    <!-- 主要内容区 -->
    <div class="main-content">
        <div class="top-bar d-flex justify-content-between align-items-center">
            <h4>欢迎回来，<?php echo htmlspecialchars($_SESSION['username']); ?></h4>
            <div>
                <span class="me-3">上次登录: <?php echo date('Y-m-d H:i:s'); ?></span>
                <button class="btn btn-outline-primary btn-sm" data-bs-toggle="modal" data-bs-target="#changePasswordModal">
                    修改密码
                </button>
            </div>
        </div>

        <?php
        // 加载相应的页面内容
        switch ($page) {
            case 'dashboard':
                include 'dashboard.php';
                break;
            case 'users':
                include 'users.php';
                break;
            case 'statistics':
                include 'statistics.php';
                break;
            case 'settings':
                include 'settings.php';
                break;
            case 'logs':
                include 'logs.php';
                break;
            default:
                include 'dashboard.php';
        }
        ?>
    </div>

    <!-- 修改密码模态框 -->
    <div class="modal fade" id="changePasswordModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">修改密码</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="post" action="change_password.php">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">当前密码</label>
                            <input type="password" class="form-control" name="old_password" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">新密码</label>
                            <input type="password" class="form-control" name="new_password" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">确认新密码</label>
                            <input type="password" class="form-control" name="confirm_password" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                        <button type="submit" class="btn btn-primary">保存</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.bootcdn.net/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
</body>
</html> 