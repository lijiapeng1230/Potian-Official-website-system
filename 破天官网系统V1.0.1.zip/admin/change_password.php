<?php
require_once '../includes/db.php';
require_once '../classes/Auth.php';

try {
    $pdo = Database::getInstance();
    $auth = new Auth($pdo);
} catch (Exception $e) {
    die("系统错误：" . $e->getMessage());
}

// 检查是否登录且是管理员
if (!$auth->isLoggedIn() || !$auth->isAdmin()) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old_password = $_POST['old_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    // 密码验证规则
    $password_pattern = '/^(?=.*[a-zA-Z])(?=.*[0-9]).{6,}$/';
    
    if ($new_password !== $confirm_password) {
        $error = '两次输入的新密码不一致';
    } elseif (!preg_match($password_pattern, $new_password)) {
        $error = '新密码必须至少6位，且包含英文和数字';
    } else {
        $result = $auth->changePassword($_SESSION['user_id'], $old_password, $new_password);
        if ($result['success']) {
            $auth->logAdminAction('change_password', '修改管理员密码');
            $success = '密码修改成功';
        } else {
            $error = $result['message'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>修改密码 - 管理后台</title>
    <link href="https://cdn.bootcdn.net/ajax/libs/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.bootcdn.net/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0f2f5;
        }
        .container {
            max-width: 600px;
            margin-top: 50px;
        }
        .card {
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h3 class="text-center mb-0">修改管理员密码</h3>
            </div>
            <div class="card-body">
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle me-2"></i><?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>
                <?php if (isset($success)): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle me-2"></i><?php echo htmlspecialchars($success); ?>
                    </div>
                <?php endif; ?>
                <form method="post">
                    <div class="mb-3">
                        <label class="form-label">当前密码</label>
                        <input type="password" class="form-control" name="old_password" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">新密码</label>
                        <input type="password" class="form-control" name="new_password" required 
                               pattern="^(?=.*[a-zA-Z])(?=.*[0-9]).{6,}$" 
                               title="密码必须至少6位，且包含英文和数字">
                        <div class="form-text">密码必须至少6位，且包含英文和数字</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">确认新密码</label>
                        <input type="password" class="form-control" name="confirm_password" required>
                    </div>
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-key me-2"></i>修改密码
                        </button>
                        <a href="index.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i>返回管理后台
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html> 