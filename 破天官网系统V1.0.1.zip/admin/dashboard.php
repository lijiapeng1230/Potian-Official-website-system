<?php
// 防止直接访问
if (!defined('IN_ADMIN')) {
    exit('Access Denied');
}

// 获取最近的操作日志
$recentLogs = $pdo->query("
    SELECT al.*, u.username 
    FROM admin_logs al
    JOIN users u ON al.admin_id = u.id
    ORDER BY al.created_at DESC 
    LIMIT 5
")->fetchAll();

// 获取最新注册的用户
$newUsers = $pdo->query("
    SELECT * FROM users 
    ORDER BY created_at DESC 
    LIMIT 5
")->fetchAll();

// 获取今日数据
$todayStats = [
    'downloads' => $pdo->query("SELECT COUNT(*) FROM download_stats WHERE DATE(download_time) = CURDATE()")->fetchColumn(),
    'new_users' => $pdo->query("SELECT COUNT(*) FROM users WHERE DATE(created_at) = CURDATE()")->fetchColumn(),
    'vip_users' => $pdo->query("SELECT COUNT(*) FROM users WHERE is_vip = 1")->fetchColumn(),
    'total_users' => $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn()
];
?>

<!-- 统计卡片 -->
<div class="row">
    <div class="col-md-3">
        <div class="stat-card text-center">
            <i class="fas fa-users"></i>
            <h3><?php echo $todayStats['total_users']; ?></h3>
            <p>总用户数</p>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card text-center">
            <i class="fas fa-crown"></i>
            <h3><?php echo $todayStats['vip_users']; ?></h3>
            <p>VIP用户数</p>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card text-center">
            <i class="fas fa-download"></i>
            <h3><?php echo $todayStats['downloads']; ?></h3>
            <p>今日下载次数</p>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card text-center">
            <i class="fas fa-user-plus"></i>
            <h3><?php echo $todayStats['new_users']; ?></h3>
            <p>今日新增用户</p>
        </div>
    </div>
</div>

<!-- 快捷操作 -->
<div class="quick-actions">
    <h5 class="mb-3">快捷操作</h5>
    <div class="d-flex flex-wrap">
        <button class="action-btn" onclick="location.href='?page=users'">
            <i class="fas fa-user-edit"></i> 用户管理
        </button>
        <button class="action-btn" onclick="location.href='?page=statistics'">
            <i class="fas fa-chart-line"></i> 查看统计
        </button>
        <button class="action-btn" onclick="location.href='?page=settings'">
            <i class="fas fa-cog"></i> 系统设置
        </button>
        <button class="action-btn" onclick="location.href='?page=logs'">
            <i class="fas fa-list"></i> 查看日志
        </button>
    </div>
</div>

<!-- 最近操作日志 -->
<div class="card mb-4">
    <div class="card-header">
        <h5>最近操作日志</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>管理员</th>
                        <th>操作类型</th>
                        <th>操作详情</th>
                        <th>操作时间</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recentLogs as $log): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($log['username']); ?></td>
                            <td><?php echo htmlspecialchars($log['action_type']); ?></td>
                            <td><?php echo htmlspecialchars($log['action_detail']); ?></td>
                            <td><?php echo date('Y-m-d H:i:s', strtotime($log['created_at'])); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- 最新注册用户 -->
<div class="card">
    <div class="card-header">
        <h5>最新注册用户</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>用户名</th>
                        <th>邮箱</th>
                        <th>注册时间</th>
                        <th>VIP状态</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($newUsers as $user): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($user['username']); ?></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td><?php echo date('Y-m-d H:i:s', strtotime($user['created_at'])); ?></td>
                            <td><?php echo $user['is_vip'] ? 'VIP' : '普通用户'; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div> 