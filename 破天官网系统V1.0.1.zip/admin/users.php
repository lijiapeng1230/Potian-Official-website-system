<?php
require_once '../config/database.php';
require_once '../classes/Auth.php';

$auth = new Auth($pdo);

// 检查是否登录且是管理员
if (!$auth->isLoggedIn() || !$auth->isAdmin()) {
    header('Location: login.php');
    exit;
}

// 处理用户操作
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'delete_user':
                if (isset($_POST['user_id'])) {
                    // 检查是否是最后一个管理员
                    $stmt = $pdo->prepare("SELECT is_admin FROM users WHERE id = ?");
                    $stmt->execute([$_POST['user_id']]);
                    $user = $stmt->fetch();
                    
                    if ($user['is_admin']) {
                        $adminCount = $pdo->query("SELECT COUNT(*) FROM users WHERE is_admin = 1")->fetchColumn();
                        if ($adminCount <= 1) {
                            $error = '不能删除最后一个管理员';
                            break;
                        }
                    }
                    
                    // 删除用户相关数据
                    $pdo->beginTransaction();
                    try {
                        // 删除下载记录
                        $stmt = $pdo->prepare("DELETE FROM download_stats WHERE user_id = ?");
                        $stmt->execute([$_POST['user_id']]);
                        
                        // 删除操作日志
                        $stmt = $pdo->prepare("DELETE FROM admin_logs WHERE admin_id = ?");
                        $stmt->execute([$_POST['user_id']]);
                        
                        // 删除用户
                        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
                        $stmt->execute([$_POST['user_id']]);
                        
                        $pdo->commit();
                        $auth->logAdminAction('delete_user', '删除用户ID: ' . $_POST['user_id']);
                        $success = '用户已删除';
                    } catch (Exception $e) {
                        $pdo->rollBack();
                        $error = '删除用户失败：' . $e->getMessage();
                    }
                }
                break;
                
            case 'update_user':
                if (isset($_POST['user_id'])) {
                    $pdo->beginTransaction();
                    try {
                        $stmt = $pdo->prepare("
                            UPDATE users 
                            SET username = ?,
                                email = ?,
                                is_admin = ?,
                                is_vip = ?,
                                vip_level = ?,
                                vip_expire_time = ?,
                                status = ?
                            WHERE id = ?
                        ");
                        
                        $stmt->execute([
                            $_POST['username'],
                            $_POST['email'],
                            isset($_POST['is_admin']) ? 1 : 0,
                            isset($_POST['is_vip']) ? 1 : 0,
                            $_POST['vip_level'],
                            $_POST['vip_expire_time'] ?: null,
                            isset($_POST['status']) ? 1 : 0,
                            $_POST['user_id']
                        ]);
                        
                        // 如果提供了新密码，则更新密码
                        if (!empty($_POST['new_password'])) {
                            $hashedPassword = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
                            $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
                            $stmt->execute([$hashedPassword, $_POST['user_id']]);
                        }
                        
                        $pdo->commit();
                        $auth->logAdminAction('update_user', '更新用户ID: ' . $_POST['user_id']);
                        $success = '用户信息已更新';
                    } catch (Exception $e) {
                        $pdo->rollBack();
                        $error = '更新用户失败：' . $e->getMessage();
                    }
                }
                break;
                
            case 'add_user':
                try {
                    $pdo->beginTransaction();
                    
                    // 检查用户名和邮箱是否已存在
                    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
                    $stmt->execute([$_POST['username'], $_POST['email']]);
                    if ($stmt->rowCount() > 0) {
                        throw new Exception('用户名或邮箱已存在');
                    }
                    
                    // 创建新用户
                    $stmt = $pdo->prepare("
                        INSERT INTO users (
                            username, 
                            email, 
                            password, 
                            is_admin, 
                            is_vip, 
                            vip_level, 
                            vip_expire_time,
                            status
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, 1)
                    ");
                    
                    $stmt->execute([
                        $_POST['username'],
                        $_POST['email'],
                        password_hash($_POST['password'], PASSWORD_DEFAULT),
                        isset($_POST['is_admin']) ? 1 : 0,
                        isset($_POST['is_vip']) ? 1 : 0,
                        $_POST['vip_level'],
                        $_POST['vip_expire_time'] ?: null
                    ]);
                    
                    $pdo->commit();
                    $auth->logAdminAction('add_user', '添加新用户：' . $_POST['username']);
                    $success = '用户添加成功';
                } catch (Exception $e) {
                    $pdo->rollBack();
                    $error = '添加用户失败：' . $e->getMessage();
                }
                break;
        }
    }
}

// 获取所有用户
$stmt = $pdo->query("
    SELECT id, username, email, is_admin, is_vip, vip_level, vip_expire_time, status, created_at 
    FROM users 
    ORDER BY id DESC
");
$users = $stmt->fetchAll();
?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5>用户管理</h5>
        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addUserModal">
            <i class="fas fa-plus"></i> 添加用户
        </button>
    </div>
    <div class="card-body">
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>用户名</th>
                        <th>邮箱</th>
                        <th>角色</th>
                        <th>VIP等级</th>
                        <th>VIP到期时间</th>
                        <th>状态</th>
                        <th>注册时间</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($user['id']); ?></td>
                            <td><?php echo htmlspecialchars($user['username']); ?></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td>
                                <?php if ($user['is_admin']): ?>
                                    <span class="badge bg-danger">管理员</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">普通用户</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php
                                switch($user['vip_level']) {
                                    case 3: echo '<span class="badge bg-warning text-dark">黄金VIP</span>'; break;
                                    case 2: echo '<span class="badge bg-light text-dark">白银VIP</span>'; break;
                                    case 1: echo '<span class="badge bg-secondary">青铜VIP</span>'; break;
                                    default: echo '<span class="badge bg-secondary">普通会员</span>';
                                }
                                ?>
                            </td>
                            <td><?php echo $user['vip_expire_time'] ? date('Y-m-d', strtotime($user['vip_expire_time'])) : '-'; ?></td>
                            <td>
                                <?php if ($user['status']): ?>
                                    <span class="badge bg-success">正常</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">禁用</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo date('Y-m-d', strtotime($user['created_at'])); ?></td>
                            <td>
                                <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#editModal<?php echo $user['id']; ?>">
                                    编辑
                                </button>
                                <?php if (!$user['is_admin'] || ($user['is_admin'] && $adminCount > 1)): ?>
                                    <button class="btn btn-danger btn-sm" onclick="confirmDelete(<?php echo $user['id']; ?>)">
                                        删除
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        
                        <!-- 编辑用户模态框 -->
                        <div class="modal fade" id="editModal<?php echo $user['id']; ?>" tabindex="-1">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">编辑用户</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <form method="post">
                                        <input type="hidden" name="action" value="update_user">
                                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                        <div class="modal-body">
                                            <div class="mb-3">
                                                <label class="form-label">用户名</label>
                                                <input type="text" class="form-control" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">邮箱</label>
                                                <input type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">新密码（留空则不修改）</label>
                                                <input type="password" class="form-control" name="new_password">
                                            </div>
                                            <div class="mb-3">
                                                <div class="form-check">
                                                    <input type="checkbox" class="form-check-input" name="is_admin" <?php echo $user['is_admin'] ? 'checked' : ''; ?>>
                                                    <label class="form-check-label">管理员权限</label>
                                                </div>
                                            </div>
                                            <div class="mb-3">
                                                <div class="form-check">
                                                    <input type="checkbox" class="form-check-input" name="is_vip" <?php echo $user['is_vip'] ? 'checked' : ''; ?>>
                                                    <label class="form-check-label">VIP用户</label>
                                                </div>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">VIP等级</label>
                                                <select name="vip_level" class="form-select">
                                                    <option value="0" <?php echo $user['vip_level'] == 0 ? 'selected' : ''; ?>>普通会员</option>
                                                    <option value="1" <?php echo $user['vip_level'] == 1 ? 'selected' : ''; ?>>青铜VIP</option>
                                                    <option value="2" <?php echo $user['vip_level'] == 2 ? 'selected' : ''; ?>>白银VIP</option>
                                                    <option value="3" <?php echo $user['vip_level'] == 3 ? 'selected' : ''; ?>>黄金VIP</option>
                                                </select>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">VIP到期时间</label>
                                                <input type="datetime-local" class="form-control" name="vip_expire_time" 
                                                    value="<?php echo $user['vip_expire_time'] ? date('Y-m-d\TH:i', strtotime($user['vip_expire_time'])) : ''; ?>">
                                            </div>
                                            <div class="mb-3">
                                                <div class="form-check">
                                                    <input type="checkbox" class="form-check-input" name="status" <?php echo $user['status'] ? 'checked' : ''; ?>>
                                                    <label class="form-check-label">账号状态（勾选为启用）</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                                            <button type="submit" class="btn btn-primary">保存</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- 删除用户的表单 -->
<form id="deleteForm" method="post" style="display: none;">
    <input type="hidden" name="action" value="delete_user">
    <input type="hidden" name="user_id" id="deleteUserId">
</form>

<script>
function confirmDelete(userId) {
    if (confirm('确定要删除这个用户吗？此操作不可恢复！')) {
        document.getElementById('deleteUserId').value = userId;
        document.getElementById('deleteForm').submit();
    }
}
</script> 

<!-- 在表格后面添加新用户模态框 -->
<div class="modal fade" id="addUserModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">添加新用户</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <input type="hidden" name="action" value="add_user">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">用户名</label>
                        <input type="text" class="form-control" name="username" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">邮箱</label>
                        <input type="email" class="form-control" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">密码</label>
                        <input type="password" class="form-control" name="password" required>
                    </div>
                    <div class="mb-3">
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" name="is_admin">
                            <label class="form-check-label">管理员权限</label>
                        </div>
                    </div>
                    <div class="mb-3">
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" name="is_vip">
                            <label class="form-check-label">VIP用户</label>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">VIP等级</label>
                        <select name="vip_level" class="form-select">
                            <option value="0">普通会员</option>
                            <option value="1">青铜VIP</option>
                            <option value="2">白银VIP</option>
                            <option value="3">黄金VIP</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">VIP到期时间</label>
                        <input type="datetime-local" class="form-control" name="vip_expire_time">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                    <button type="submit" class="btn btn-primary">添加</button>
                </div>
            </form>
        </div>
    </div>
</div> 