<?php
require_once '../config/database.php';
require_once '../classes/Auth.php';

$auth = new Auth($pdo);

// 检查是否登录且是管理员
if (!$auth->isLoggedIn() || !$auth->isAdmin()) {
    header('Location: login.php');
    exit;
}

// 获取下载统计
$downloadStats = $pdo->query("
    SELECT 
        u.username,
        d.download_type,
        COUNT(*) as download_count,
        MAX(d.download_time) as last_download,
        MIN(d.download_time) as first_download
    FROM download_stats d
    JOIN users u ON d.user_id = u.id
    GROUP BY u.username, d.download_type
    ORDER BY download_count DESC
")->fetchAll();

// 获取用户活跃度统计
$userActivity = $pdo->query("
    SELECT 
        u.username,
        COUNT(d.id) as total_downloads,
        MAX(d.download_time) as last_activity
    FROM users u
    LEFT JOIN download_stats d ON u.id = d.user_id
    GROUP BY u.id, u.username
    ORDER BY total_downloads DESC
")->fetchAll();

// 获取软件受欢迎程度统计
$softwarePopularity = $pdo->query("
    SELECT 
        download_type,
        COUNT(*) as total_downloads,
        COUNT(DISTINCT user_id) as unique_users
    FROM download_stats
    GROUP BY download_type
    ORDER BY total_downloads DESC
")->fetchAll();

// 软件名称映射
$softwareNames = [
    'server_management' => '服务器管理系统5.0',
    'system_rescue' => '黎明系统急救箱',
    'ping_tool' => 'Ping包测试工具'
];
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>数据统计 - 管理后台</title>
    <link href="https://cdn.bootcdn.net/ajax/libs/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.bootcdn.net/ajax/libs/echarts/5.4.3/echarts.min.js"></script>
    <style>
        .chart-container {
            height: 400px;
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>数据统计</h2>
            <a href="index.php" class="btn btn-primary">返回管理首页</a>
        </div>

        <!-- 软件下载统计图表 -->
        <div class="card mb-4">
            <div class="card-header">
                <h4>软件下载趋势</h4>
            </div>
            <div class="card-body">
                <div id="downloadChart" class="chart-container"></div>
            </div>
        </div>

        <!-- 用户活跃度统计 -->
        <div class="card mb-4">
            <div class="card-header">
                <h4>用户活跃度排行</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>用户名</th>
                                <th>总下载次数</th>
                                <th>最后活动时间</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($userActivity as $activity): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($activity['username']); ?></td>
                                    <td><?php echo htmlspecialchars($activity['total_downloads']); ?></td>
                                    <td><?php echo $activity['last_activity'] ? date('Y-m-d H:i:s', strtotime($activity['last_activity'])) : '-'; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- 软件受欢迎程度统计 -->
        <div class="card mb-4">
            <div class="card-header">
                <h4>软件受欢迎程度</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>软件名称</th>
                                <th>总下载次数</th>
                                <th>独立用户数</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($softwarePopularity as $software): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($softwareNames[$software['download_type']] ?? $software['download_type']); ?></td>
                                    <td><?php echo htmlspecialchars($software['total_downloads']); ?></td>
                                    <td><?php echo htmlspecialchars($software['unique_users']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.bootcdn.net/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
    <script>
        // 初始化ECharts图表
        var downloadChart = echarts.init(document.getElementById('downloadChart'));
        
        // 准备数据
        var downloadData = <?php echo json_encode($downloadStats); ?>;
        var softwareNames = <?php echo json_encode($softwareNames); ?>;
        
        // 处理数据
        var series = [];
        var softwareTypes = [...new Set(downloadData.map(item => item.download_type))];
        
        softwareTypes.forEach(type => {
            var data = downloadData.filter(item => item.download_type === type);
            series.push({
                name: softwareNames[type] || type,
                type: 'bar',
                data: data.map(item => item.download_count)
            });
        });

        // 配置图表选项
        var option = {
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'shadow'
                }
            },
            legend: {
                data: softwareTypes.map(type => softwareNames[type] || type)
            },
            xAxis: {
                type: 'category',
                data: [...new Set(downloadData.map(item => item.username))]
            },
            yAxis: {
                type: 'value'
            },
            series: series
        };

        // 使用配置项显示图表
        downloadChart.setOption(option);
    </script>
</body>
</html> 