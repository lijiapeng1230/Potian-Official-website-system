<?php
// 防止直接访问
if (!defined('IN_ADMIN')) {
    exit('Access Denied');
}

// 获取筛选参数
$actionType = $_GET['action_type'] ?? '';
$startDate = $_GET['start_date'] ?? '';
$endDate = $_GET['end_date'] ?? '';
$adminId = $_GET['admin_id'] ?? '';

// 构建查询
$query = "
    SELECT 
        al.*,
        u.username as admin_username
    FROM admin_logs al
    JOIN users u ON al.admin_id = u.id
    WHERE 1=1
";
$params = [];

if ($actionType) {
    $query .= " AND al.action_type = ?";
    $params[] = $actionType;
}

if ($startDate) {
    $query .= " AND DATE(al.created_at) >= ?";
    $params[] = $startDate;
}

if ($endDate) {
    $query .= " AND DATE(al.created_at) <= ?";
    $params[] = $endDate;
}

if ($adminId) {
    $query .= " AND al.admin_id = ?";
    $params[] = $adminId;
}

$query .= " ORDER BY al.created_at DESC";

// 执行查询
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$logs = $stmt->fetchAll();

// 获取所有管理员
$admins = $pdo->query("SELECT id, username FROM users WHERE is_admin = 1")->fetchAll();

// 获取所有操作类型
$actionTypes = $pdo->query("SELECT DISTINCT action_type FROM admin_logs")->fetchAll(PDO::FETCH_COLUMN);
?>

<div class="card">
    <div class="card-header">
        <h5>操作日志</h5>
    </div>
    <div class="card-body">
        <!-- 筛选表单 -->
        <div class="filter-form mb-4">
            <form method="get" class="row g-3">
                <input type="hidden" name="page" value="logs">
                <div class="col-md-3">
                    <label class="form-label">操作类型</label>
                    <select name="action_type" class="form-select">
                        <option value="">全部</option>
                        <?php foreach ($actionTypes as $type): ?>
                            <option value="<?php echo htmlspecialchars($type); ?>" 
                                <?php echo $actionType === $type ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($type); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">管理员</label>
                    <select name="admin_id" class="form-select">
                        <option value="">全部</option>
                        <?php foreach ($admins as $admin): ?>
                            <option value="<?php echo $admin['id']; ?>"
                                <?php echo $adminId == $admin['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($admin['username']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">开始日期</label>
                    <input type="date" name="start_date" class="form-control" value="<?php echo $startDate; ?>">
                </div>
                <div class="col-md-2">
                    <label class="form-label">结束日期</label>
                    <input type="date" name="end_date" class="form-control" value="<?php echo $endDate; ?>">
                </div>
                <div class="col-md-2">
                    <label class="form-label">&nbsp;</label>
                    <button type="submit" class="btn btn-primary w-100">筛选</button>
                </div>
            </form>
        </div>

        <!-- 日志列表 -->
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>管理员</th>
                        <th>操作类型</th>
                        <th>操作详情</th>
                        <th>IP地址</th>
                        <th>操作时间</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $log): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($log['id']); ?></td>
                            <td><?php echo htmlspecialchars($log['admin_username']); ?></td>
                            <td><?php echo htmlspecialchars($log['action_type']); ?></td>
                            <td><?php echo htmlspecialchars($log['action_detail']); ?></td>
                            <td><?php echo htmlspecialchars($log['ip_address']); ?></td>
                            <td><?php echo date('Y-m-d H:i:s', strtotime($log['created_at'])); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div> 