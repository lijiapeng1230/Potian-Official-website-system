<?php
require_once '../config/database.php';
require_once '../classes/Auth.php';

$auth = new Auth($pdo);
$error = '';

// 如果已经登录且是管理员，直接跳转到管理后台
if ($auth->isLoggedIn() && $auth->isAdmin()) {
    header('Location: index.php');
    exit;
}

// 处理登录请求
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if ($auth->login($username, $password)) {
        if ($auth->isAdmin()) {
            header('Location: index.php');
            exit;
        } else {
            $error = '您没有管理员权限';
        }
    } else {
        $error = '用户名或密码错误';
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理后台 - 破天星辰科技网络</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background: url('background4.webp') no-repeat center center fixed;
            background-size: cover;
            font-family: Arial, sans-serif;
        }

        .container {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
            color: white;
        }

        h1 {
            font-size: 2em;
        }

        p {
            font-size: 1.2em;
        }

        .login-box {
            width: 300px;
            margin: 20px auto;
            padding: 15px;
            background: rgba(0, 0, 0, 0.7);
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        }

        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            box-sizing: border-box;
            border: none;
            border-radius: 5px;
        }

        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
        }

        button:hover {
            background-color: #45a049;
        }

        .error-message {
            color: #ff6b6b;
            margin-top: 10px;
            font-size: 0.9em;
        }

        footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background: rgba(0, 0, 0, 0.7);
            color: white;
            text-align: center;
            padding: 10px 0;
        }

        .back-link {
            position: fixed;
            top: 20px;
            left: 20px;
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            background: rgba(0, 0, 0, 0.7);
            border-radius: 5px;
        }

        .back-link:hover {
            background: rgba(0, 0, 0, 0.9);
        }
    </style>
</head>
<body>
    <a href="../" class="back-link">返回首页</a>
    
    <div class="container">
        <h1>破天星辰科技网络管理后台</h1>
        <div class="login-box">
            <p>管理员登录</p>
            <form method="post">
                <input type="text" name="username" placeholder="用户名" required>
                <input type="password" name="password" placeholder="密码" required>
                <button type="submit">登录</button>
            </form>
            <?php if ($error): ?>
                <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
        </div>
    </div>

    <footer>
        &copy; <?php echo date('Y'); ?> 破天星辰科技网络版权所有
    </footer>
</body>
</html> 