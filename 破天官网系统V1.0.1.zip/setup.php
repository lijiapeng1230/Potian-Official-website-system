<?php
require_once 'check_install.php';

// 修改安装检测逻辑
if (!InstallationChecker::needsInstallation()) {
    echo '<script>alert("系统已经安装！正在跳转到首页..."); window.location.href = "index.php";</script>';
    exit;
}

// 检查PHP版本
$required_php_version = '7.4.0';
$php_check = version_compare(PHP_VERSION, $required_php_version, '>=');

// 检查必要的PHP扩展
$required_extensions = ['pdo', 'pdo_mysql', 'mysqli', 'mbstring', 'json'];
$extension_checks = array_map('extension_loaded', $required_extensions);

// 检查MySQL版本
function checkMySQLVersion() {
    try {
        if (extension_loaded('mysqli')) {
            $mysqli = new mysqli();
            $version = mysqli_get_client_info();
            return version_compare($version, '5.6.0', '>=');
        }
        return false;
    } catch (Exception $e) {
        return false;
    }
}

// 检查目录权限
function checkDirectoryPermissions() {
    $directories = [
        'config',
        'logs',
        'uploads'
    ];
    
    $permissions = [];
    foreach ($directories as $dir) {
        if (!file_exists($dir)) {
            @mkdir($dir, 0755, true);
        }
        $permissions[$dir] = is_writable($dir);
    }
    return $permissions;
}

// 修改测试数据库连接函数
function testDatabaseConnection($host, $user, $pass, $name) {
    try {
        // 验证输入
        if (empty($host) || empty($user)) {
            throw new Exception('数据库主机和用户名不能为空');
        }

        // 先测试不带数据库名的连接
        $dsn = "mysql:host=$host;charset=utf8mb4";
        $pdo = new PDO($dsn, $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ]);

        // 检查数据库是否存在
        $stmt = $pdo->query("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = " . $pdo->quote($name));
        $exists = $stmt->fetch();

        if (!$exists) {
            // 创建数据库
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `$name` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        }

        // 连接到指定数据库
        $pdo->exec("USE `$name`");

        return ['success' => true, 'pdo' => $pdo];
    } catch (PDOException $e) {
        return ['success' => false, 'error' => '数据库连接失败: ' . $e->getMessage()];
    }
}

// 修改处理表单提交部分
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 验证表单数据
    $db_host = trim($_POST['db_host'] ?? '');
    $db_name = trim($_POST['db_name'] ?? '');
    $db_user = trim($_POST['db_user'] ?? '');
    $db_pass = $_POST['db_pass'] ?? '';
    
    $admin_username = trim($_POST['admin_username'] ?? '');
    $admin_password = $_POST['admin_password'] ?? '';
    $admin_email = trim($_POST['admin_email'] ?? '');
    
    // 验证必填字段
    if (empty($db_host) || empty($db_name) || empty($db_user)) {
        $error_message = '请填写所有必要的数据库信息';
    } elseif (empty($admin_username) || empty($admin_password)) {
        $error_message = '请填写管理员账号信息';
    } elseif (strlen($admin_password) < 6) {
        $error_message = '管理员密码至少需要6个字符';
    } else {
        try {
            // 测试数据库连接
            $db_test = testDatabaseConnection($db_host, $db_user, $db_pass, $db_name);
            if (!$db_test['success']) {
                throw new Exception($db_test['error']);
            }
            
            $pdo = $db_test['pdo'];
            
            // 开始事务
            $pdo->beginTransaction();
            
            try {
                // 先删除所有表（如果存在）
                $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
                
                // 禁用外键检查
                $pdo->exec('SET FOREIGN_KEY_CHECKS = 0');
                
                foreach ($tables as $table) {
                    $pdo->exec("DROP TABLE IF EXISTS `$table`");
                }
                
                // 启用外键检查
                $pdo->exec('SET FOREIGN_KEY_CHECKS = 1');
                
                // 导入数据库结构
                $sql = file_get_contents('database/install.sql');
                $statements = array_filter(array_map('trim', explode(';', $sql)));
                
                foreach ($statements as $statement) {
                    if (!empty($statement)) {
                        $pdo->exec($statement);
                    }
                }
                
                // 插入管理员账号
                $stmt = $pdo->prepare("INSERT INTO users (username, email, password, is_admin, status) VALUES (?, ?, ?, 1, 1)");
                $hashed_password = password_hash($admin_password, PASSWORD_DEFAULT);
                $stmt->execute([$admin_username, $admin_email, $hashed_password]);
                
                // 提交事务
                $pdo->commit();
                
                // 创建配置文件
                $config_content = "<?php\nreturn [\n    'db_host' => '{$db_host}',\n    'db_name' => '{$db_name}',\n    'db_user' => '{$db_user}',\n    'db_pass' => '{$db_pass}'\n];";
                
                if (!is_dir('config')) {
                    mkdir('config', 0755, true);
                }
                
                file_put_contents('config/database.php', $config_content);
                file_put_contents('config/installed.lock', date('Y-m-d H:i:s'));
                
                echo '<script>
                    alert("安装成功！\n管理员账号：' . $admin_username . '\n请牢记您设置的密码！");
                    window.location.href = "admin/login.php";
                </script>';
                exit;
                
            } catch (Exception $e) {
                $pdo->rollBack();
                throw $e;
            }
            
        } catch (Exception $e) {
            $error_message = '安装失败：' . $e->getMessage();
        }
    }
}

$dir_permissions = checkDirectoryPermissions();
?>

<!DOCTYPE html>
<html>
<head>
    <title>破天官网系统V1.0.1安装向导</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.bootcdn.net/ajax/libs/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        .check-item {
            margin: 15px 0;
            padding: 10px;
            border-radius: 5px;
            background: #f8f9fa;
        }
        .success { color: #198754; }
        .error { color: #dc3545; }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="mb-4">破天极简官网系统V1.0.1安装向导</h1>
        
        <!-- 环境检查 -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">环境检查</h5>
            </div>
            <div class="card-body">
                <div class="check-item">
                    PHP版本 (要求 >= <?php echo $required_php_version; ?>):
                    <span class="<?php echo $php_check ? 'success' : 'error'; ?>">
                        <?php echo PHP_VERSION; ?> <?php echo $php_check ? '✓' : '✗'; ?>
                    </span>
                </div>
                
                <?php foreach ($required_extensions as $i => $ext): ?>
                <div class="check-item">
                    PHP扩展 <?php echo $ext; ?>:
                    <span class="<?php echo $extension_checks[$i] ? 'success' : 'error'; ?>">
                        <?php echo $extension_checks[$i] ? '✓' : '✗'; ?>
                    </span>
                </div>
                <?php endforeach; ?>
                
                <div class="check-item">
                    MySQL版本 (要求 >= 5.6.0):
                    <span class="<?php echo checkMySQLVersion() ? 'success' : 'error'; ?>">
                        <?php echo checkMySQLVersion() ? '✓' : '✗'; ?>
                    </span>
                </div>
                
                <?php foreach ($dir_permissions as $dir => $writable): ?>
                <div class="check-item">
                    目录 <?php echo $dir; ?> 权限:
                    <span class="<?php echo $writable ? 'success' : 'error'; ?>">
                        <?php echo $writable ? '可写 ✓' : '不可写 ✗'; ?>
                    </span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        
        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger"><?php echo $error_message; ?></div>
        <?php endif; ?>
        
        <!-- 安装表单 -->
        <form method="POST" class="needs-validation" novalidate>
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">数据库配置</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">数据库主机:</label>
                        <input type="text" class="form-control" name="db_host" value="localhost" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">数据库名称:</label>
                        <input type="text" class="form-control" name="db_name" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">数据库用户名:</label>
                        <input type="text" class="form-control" name="db_user" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">数据库密码:</label>
                        <input type="password" class="form-control" name="db_pass" required>
                    </div>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">管理员账号设置</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">管理员用户名:</label>
                        <input type="text" class="form-control" name="admin_username" value="admin" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">管理员密码:</label>
                        <input type="password" class="form-control" name="admin_password" required minlength="6">
                        <div class="form-text">密码至少6个字符</div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">管理员邮箱:</label>
                        <input type="email" class="form-control" name="admin_email" value="admin@xctcn.cn" required>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary btn-lg w-100">
                开始安装
            </button>
        </form>
    </div>

    <script src="https://cdn.bootcdn.net/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
</body>
</html> 