<?php
class Auth {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
        session_start();
    }
    
    public function register($username, $email, $password) {
        // 验证用户名和邮箱是否已存在
        $stmt = $this->pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $email]);
        if ($stmt->rowCount() > 0) {
            return ['success' => false, 'message' => '用户名或邮箱已存在'];
        }
        
        // 密码加密
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        
        $stmt = $this->pdo->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
        if ($stmt->execute([$username, $email, $hashedPassword])) {
            return ['success' => true, 'message' => '注册成功'];
        }
        return ['success' => false, 'message' => '注册失败'];
    }
    
    public function login($username, $password) {
        $stmt = $this->pdo->prepare("SELECT * FROM users WHERE username = ? AND status = 1");
        $stmt->execute([$username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['is_admin'] = $user['is_admin'];
            return ['success' => true, 'message' => '登录成功'];
        }
        return ['success' => false, 'message' => '用户名或密码错误'];
    }
    
    public function isLoggedIn() {
        return isset($_SESSION['user_id']);
    }
    
    public function isAdmin() {
        return isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1;
    }
    
    public function logout() {
        session_destroy();
    }
    
    public function getUserCount() {
        $stmt = $this->pdo->query("SELECT COUNT(*) FROM users");
        return $stmt->fetchColumn();
    }
    
    public function changePassword($userId, $oldPassword, $newPassword) {
        // 验证旧密码
        $stmt = $this->pdo->prepare("SELECT password FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$user || !password_verify($oldPassword, $user['password'])) {
            return ['success' => false, 'message' => '当前密码错误'];
        }
        
        // 更新新密码
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        $stmt = $this->pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
        
        if ($stmt->execute([$hashedPassword, $userId])) {
            return ['success' => true, 'message' => '密码修改成功'];
        }
        
        return ['success' => false, 'message' => '密码修改失败'];
    }
    
    public function isVip() {
        if (!$this->isLoggedIn()) {
            return false;
        }
        
        $stmt = $this->pdo->prepare("SELECT is_vip, vip_expire_time FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();
        
        if (!$user) {
            return false;
        }
        
        // 检查VIP状态和过期时间
        return $user['is_vip'] == 1 && 
               ($user['vip_expire_time'] === null || strtotime($user['vip_expire_time']) > time());
    }
    
    public function setVip($userId, $status, $expireTime = null) {
        $stmt = $this->pdo->prepare("
            UPDATE users 
            SET is_vip = ?, 
                vip_expire_time = ? 
            WHERE id = ?
        ");
        return $stmt->execute([$status ? 1 : 0, $expireTime, $userId]);
    }
    
    public function getVipInfo($userId) {
        $stmt = $this->pdo->prepare("
            SELECT is_vip, vip_expire_time, vip_level 
            FROM users 
            WHERE id = ?
        ");
        $stmt->execute([$userId]);
        return $stmt->fetch();
    }
    
    public function logAdminAction($actionType, $actionDetail) {
        if (!$this->isAdmin()) {
            return false;
        }
        
        $stmt = $this->pdo->prepare("
            INSERT INTO admin_logs (admin_id, action_type, action_detail, ip_address, user_agent)
            VALUES (?, ?, ?, ?, ?)
        ");
        
        return $stmt->execute([
            $_SESSION['user_id'],
            $actionType,
            $actionDetail,
            $_SERVER['REMOTE_ADDR'],
            $_SERVER['HTTP_USER_AGENT']
        ]);
    }
} 