<?php
class Captcha {
    public static function generate() {
        // 生成简单的数字验证码
        $code = rand(1000, 9999);
        $_SESSION['captcha'] = $code;
        
        // 使用文本方式显示验证码
        header('Content-Type: text/plain');
        echo $code;
    }
    
    public static function verify($code) {
        return isset($_SESSION['captcha']) && $code == $_SESSION['captcha'];
    }
} 