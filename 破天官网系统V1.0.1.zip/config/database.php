<?php
try {
    $host = 'localhost';
    $dbname = 'admin2';
    $username = 'admin2';
    $password = '2BHZMrSAk8bCCxNJ';
    $charset = 'utf8mb4';

    $dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];

    $pdo = new PDO($dsn, $username, $password, $options);
} catch(PDOException $e) {
    die('连接数据库失败: ' . $e->getMessage());
} 