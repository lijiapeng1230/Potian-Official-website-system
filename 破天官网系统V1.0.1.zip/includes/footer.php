</div>
<footer class="bg-dark text-light mt-5">
    <div class="container py-4">
        <div class="row">
            <div class="col-md-6">
                <h5>关于我们</h5>
                <p>破天星辰科技网络致力于提供优质的技术服务和解决方案。</p>
            </div>
            <div class="col-md-6">
                <h5>联系方式</h5>
                <p>邮箱：potiankeji2022@163.com</p>
            </div>
        </div>
        <hr>
        <div class="text-center">
            <p>&copy; <?php echo date('Y'); ?> 破天星辰科技网络 版权所有</p>
        </div>
    </div>
</footer>
<script src="https://cdn.bootcdn.net/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
</body>
</html> 