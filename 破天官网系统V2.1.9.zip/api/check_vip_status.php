<?php
require_once '../includes/db.php';
require_once '../classes/Auth.php';

header('Content-Type: application/json');

try {
    $pdo = Database::getInstance();
    $auth = new Auth($pdo);

    if (!$auth->isLoggedIn()) {
        throw new Exception('请先登录');
    }

    $orderNo = $_GET['order_no'] ?? '';

    $stmt = $pdo->prepare("
        SELECT status, payment_time 
        FROM vip_orders 
        WHERE order_no = ? AND user_id = ?
    ");
    $stmt->execute([$orderNo, $_SESSION['user_id']]);
    $order = $stmt->fetch();

    echo json_encode([
        'success' => true,
        'status' => $order['status'],
        'payment_time' => $order['payment_time']
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
} 