<?php
require_once '../includes/db.php';

try {
    $pdo = Database::getInstance();
    
    // 获取支付回调数据（示例）
    $orderNo = $_POST['order_no'] ?? '';
    $paymentStatus = $_POST['status'] ?? '';
    
    if ($paymentStatus === 'success') {
        $pdo->beginTransaction();
        
        // 更新订单状态
        $stmt = $pdo->prepare("
            UPDATE vip_orders 
            SET status = 1, payment_time = NOW() 
            WHERE order_no = ? AND status = 0
        ");
        $stmt->execute([$orderNo]);
        
        if ($stmt->rowCount() > 0) {
            // 获取订单信息
            $stmt = $pdo->prepare("
                SELECT o.*, p.duration, p.level
                FROM vip_orders o
                JOIN vip_packages p ON o.package_id = p.id
                WHERE o.order_no = ?
            ");
            $stmt->execute([$orderNo]);
            $order = $stmt->fetch();
            
            // 更新用户VIP状态
            $stmt = $pdo->prepare("
                UPDATE users 
                SET is_vip = 1,
                    vip_level = ?,
                    vip_expire_time = COALESCE(
                        GREATEST(vip_expire_time, NOW()),
                        NOW()
                    ) + INTERVAL ? DAY
                WHERE id = ?
            ");
            $stmt->execute([
                $order['level'],
                $order['duration'],
                $order['user_id']
            ]);
            
            $pdo->commit();
            echo 'success';
        } else {
            throw new Exception('订单不存在或已处理');
        }
    } else {
        throw new Exception('支付失败');
    }
    
} catch (Exception $e) {
    if (isset($pdo)) {
        $pdo->rollBack();
    }
    error_log("Payment callback error: " . $e->getMessage());
    echo 'fail';
} 