<?php
require_once '../includes/db.php';
require_once '../classes/Auth.php';

header('Content-Type: application/json');

try {
    $pdo = Database::getInstance();
    $auth = new Auth($pdo);

    if (!$auth->isLoggedIn()) {
        throw new Exception('请先登录');
    }

    $input = json_decode(file_get_contents('php://input'), true);
    $packageId = $input['package_id'] ?? 0;

    // 验证套餐
    $stmt = $pdo->prepare("SELECT * FROM vip_packages WHERE id = ? AND status = 1");
    $stmt->execute([$packageId]);
    $package = $stmt->fetch();

    if (!$package) {
        throw new Exception('无效的VIP套餐');
    }

    // 生成订单号
    $orderNo = date('YmdHis') . rand(1000, 9999);

    // 创建订单
    $stmt = $pdo->prepare("
        INSERT INTO vip_orders (user_id, package_id, order_no, amount)
        VALUES (?, ?, ?, ?)
    ");
    $stmt->execute([
        $_SESSION['user_id'],
        $packageId,
        $orderNo,
        $package['price']
    ]);

    // 生成支付二维码HTML
    $paymentHtml = '
        <div class="text-center">
            <h4>订单金额：¥' . number_format($package['price'], 2) . '</h4>
            <p>订单号：' . $orderNo . '</p>
            <div class="qrcode-container my-3">
                <img src="https://devtool.tech/api/qrcode?data=%E7%A0%B4%E5%A4%A9%E6%94%AF%E4%BB%98%E6%B5%8B%E8%AF%95API%E8%B0%83%E7%94%A8' . urlencode($orderNo) . '" alt="支付二维码">
            </div>
            <p class="text-muted">请使用支付宝或微信扫码支付</p>
        </div>
    ';

    echo json_encode([
        'success' => true,
        'html' => $paymentHtml,
        'order_no' => $orderNo
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
} 