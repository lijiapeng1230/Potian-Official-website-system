<?php
class Database {
    private static $instance = null;
    private $pdo;

    private function __construct() {
        if (!file_exists(__DIR__ . '/../config/installed.lock')) {
            die('系统未安装，请先运行安装程序');
        }

        $config = require __DIR__ . '/../config/database.php';
        try {
            $dsn = "mysql:host={$config['db_host']};dbname={$config['db_name']};charset=utf8";
            $this->pdo = new PDO($dsn, $config['db_user'], $config['db_pass'], [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false
            ]);
        } catch (PDOException $e) {
            die('数据库连接失败: ' . $e->getMessage());
        }
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance->pdo;
    }
} 