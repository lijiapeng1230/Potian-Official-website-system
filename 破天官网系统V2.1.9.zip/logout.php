<?php
require_once 'includes/db.php';
require_once 'classes/Auth.php';

try {
    $pdo = Database::getInstance();
    $auth = new Auth($pdo);
    $auth->logout();
    header('Location: login.php');
    exit;
} catch (Exception $e) {
    die("系统错误：" . $e->getMessage());
}
?> 