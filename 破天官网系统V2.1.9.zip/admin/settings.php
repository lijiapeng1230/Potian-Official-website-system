<?php
// 防止直接访问
if (!defined('IN_ADMIN')) {
    exit('Access Denied');
}

// 系统设置处理
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_settings') {
    try {
        $pdo->beginTransaction();
        
        $stmt = $pdo->prepare("
            INSERT INTO settings (setting_key, setting_value) 
            VALUES (?, ?) 
            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
        ");
        
        $settings = [
            'site_name' => $_POST['site_name'] ?? '',
            'site_description' => $_POST['site_description'] ?? '',
            'maintenance_mode' => isset($_POST['maintenance_mode']) ? '1' : '0',
            'register_enabled' => isset($_POST['register_enabled']) ? '1' : '0',
            'download_enabled' => isset($_POST['download_enabled']) ? '1' : '0'
        ];
        
        foreach ($settings as $key => $value) {
            $stmt->execute([$key, $value]);
        }
        
        $pdo->commit();
        $auth->logAdminAction('update_settings', '更新系统设置');
        $message = '设置已更新';
        
        // 刷新页面以显示新设置
        header('Location: index.php?page=settings&updated=1');
        exit;
        
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = '更新设置失败：' . $e->getMessage();
    }
}

// 获取当前设置
$settings = [];
$settingsResult = $pdo->query("SELECT setting_key, setting_value FROM settings");
while ($row = $settingsResult->fetch()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}

// 显示更新成功消息
$showSuccess = isset($_GET['updated']) && $_GET['updated'] == '1';
?>

<div class="card">
    <div class="card-header">
        <h5>系统设置</h5>
    </div>
    <div class="card-body">
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if ($showSuccess): ?>
            <div class="alert alert-success">设置已成功更新</div>
        <?php endif; ?>
        
        <form method="post" id="settingsForm">
            <input type="hidden" name="action" value="update_settings">
            
            <div class="mb-3">
                <label class="form-label">网站名称</label>
                <input type="text" class="form-control" name="site_name" 
                    value="<?php echo htmlspecialchars($settings['site_name'] ?? '破天星辰科技网络'); ?>">
            </div>
            
            <div class="mb-3">
                <label class="form-label">网站描述</label>
                <textarea class="form-control" name="site_description" rows="3"
                    ><?php echo htmlspecialchars($settings['site_description'] ?? ''); ?></textarea>
            </div>
            
            <div class="mb-3">
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" name="maintenance_mode" 
                        <?php echo ($settings['maintenance_mode'] ?? '0') == '1' ? 'checked' : ''; ?>>
                    <label class="form-check-label">维护模式</label>
                </div>
                <small class="text-muted">启用后，只有管理员可以访问网站</small>
            </div>
            
            <div class="mb-3">
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" name="register_enabled"
                        <?php echo ($settings['register_enabled'] ?? '1') == '1' ? 'checked' : ''; ?>>
                    <label class="form-check-label">允许注册</label>
                </div>
                <small class="text-muted">关闭后，新用户将无法注册</small>
            </div>
            
            <div class="mb-3">
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" name="download_enabled"
                        <?php echo ($settings['download_enabled'] ?? '1') == '1' ? 'checked' : ''; ?>>
                    <label class="form-check-label">允许下载</label>
                </div>
                <small class="text-muted">关闭后，用户将无法下载软件</small>
            </div>
            
            <button type="submit" class="btn btn-primary">保存设置</button>
        </form>
    </div>
</div> 