<?php
define('IN_ADMIN', true);
require_once '../includes/db.php';
require_once '../classes/Auth.php';

$pdo = Database::getInstance();
$auth = new Auth($pdo);

// 检查是否登录且是管理员
if (!$auth->isLoggedIn() || !$auth->isAdmin()) {
    header('Location: login.php');
    exit;
}

// 获取当前页面
$page = $_GET['page'] ?? 'dashboard';

// 获取基础统计数据
$totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$totalVipUsers = $pdo->query("SELECT COUNT(*) FROM users WHERE is_vip = 1")->fetchColumn();
$totalDownloads = $pdo->query("SELECT COUNT(*) FROM download_stats")->fetchColumn();
$newUsersToday = $pdo->query("SELECT COUNT(*) FROM users WHERE DATE(created_at) = CURDATE()")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理后台 - 破天星辰科技网络</title>
    <link href="https://cdn.bootcdn.net/ajax/libs/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.bootcdn.net/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0f2f5;
            min-height: 100vh;
        }
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: 250px;
            background: #001529;
            color: #fff;
            padding-top: 20px;
            z-index: 1000;
            transition: all 0.3s ease;
        }
        .sidebar .nav-link {
            color: #fff;
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 4px;
            transition: all 0.3s;
        }
        .sidebar .nav-link:hover {
            background: #1890ff;
            transform: translateX(5px);
        }
        .sidebar .nav-link.active {
            background: #1890ff;
            color: #fff;
        }
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
            min-height: 100vh;
        }
        .top-bar {
            background: #fff;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 12px rgba(0,0,0,0.08);
        }
        .stat-card {
            background: #fff;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 12px rgba(0,0,0,0.08);
            transition: all 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .stat-card i {
            font-size: 2em;
            margin-bottom: 10px;
            color: #1890ff;
        }
        .nav-category {
            font-size: 0.8em;
            text-transform: uppercase;
            color: #888;
            margin: 20px 20px 10px;
            border-bottom: 1px solid #333;
            padding-bottom: 5px;
        }
        .user-info {
            padding: 20px;
            margin-bottom: 20px;
            border-bottom: 1px solid #333;
        }
        .user-info .avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            margin-bottom: 10px;
        }
        .btn-change-password {
            border-color: #1890ff;
            color: #1890ff;
        }
        .btn-change-password:hover {
            background: #1890ff;
            color: #fff;
        }
        @media (max-width: 768px) {
            .sidebar {
                width: 60px;
            }
            .sidebar .nav-link span {
                display: none;
            }
            .main-content {
                margin-left: 60px;
            }
        }
    </style>
</head>
<body>
    <!-- 侧边栏 -->
    <div class="sidebar">
        <div class="user-info text-center">
            <img src="./img/admin.jpg" 
                 class="avatar" alt="用户头像">
            <h6 class="mb-0"><?php echo htmlspecialchars($_SESSION['username']); ?></h6>
            <small class="text-muted">管理员</small>
        </div>

        <div class="nav-category">主要功能</div>
        <nav class="nav flex-column">
            <a class="nav-link <?php echo $page === 'dashboard' ? 'active' : ''; ?>" href="?page=dashboard">
                <i class="fas fa-home"></i><span>控制台</span>
            </a>
            <a class="nav-link <?php echo $page === 'users' ? 'active' : ''; ?>" href="?page=users">
                <i class="fas fa-users"></i><span>用户管理</span>
            </a>
            <a class="nav-link <?php echo $page === 'vip' ? 'active' : ''; ?>" href="?page=vip">
                <i class="fas fa-crown"></i><span>VIP管理</span>
            </a>
        </nav>

        <div class="nav-category">内容管理</div>
        <nav class="nav flex-column">
            <a class="nav-link <?php echo $page === 'content' ? 'active' : ''; ?>" href="?page=content">
                <i class="fas fa-file-alt"></i><span>内容管理</span>
            </a>
            <a class="nav-link <?php echo $page === 'statistics' ? 'active' : ''; ?>" href="?page=statistics">
                <i class="fas fa-chart-bar"></i><span>数据统计</span>
            </a>
            <a class="nav-link <?php echo $page === 'logs' ? 'active' : ''; ?>" href="?page=logs">
                <i class="fas fa-history"></i><span>操作日志</span>
            </a>
        </nav>

        <div class="nav-category">系统</div>
        <nav class="nav flex-column">
            <a class="nav-link" href="../">
                <i class="fas fa-arrow-left"></i><span>返回前台</span>
            </a>
            <a class="nav-link" href="../logout.php">
                <i class="fas fa-sign-out-alt"></i><span>退出登录</span>
            </a>
        </nav>
    </div>

    <!-- 主要内容区 -->
    <div class="main-content">
        <div class="top-bar d-flex justify-content-between align-items-center">
            <div>
                <h4 class="mb-0">欢迎回来，<?php echo htmlspecialchars($_SESSION['username']); ?></h4>
                <small class="text-muted">上次登录: <?php echo date('Y-m-d H:i:s'); ?></small>
            </div>
            <button class="btn btn-outline-primary btn-sm btn-change-password" data-bs-toggle="modal" data-bs-target="#changePasswordModal">
                <i class="fas fa-key me-2"></i>修改密码
            </button>
        </div>

        <?php
        switch ($page) {
            case 'dashboard':
                include 'dashboard.php';
                break;
            case 'users':
                include 'users.php';
                break;
            case 'content':
                include 'content.php';
                break;
            case 'statistics':
                include 'statistics.php';
                break;
            case 'logs':
                include 'logs.php';
                break;
            case 'vip':
                include 'vip.php';
                break;
            default:
                include 'dashboard.php';
        }
        ?>
    </div>

    <!-- 修改密码模态框 -->
    <div class="modal fade" id="changePasswordModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">修改密码</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="post" action="change_password.php">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">当前密码</label>
                            <input type="password" class="form-control" name="old_password" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">新密码</label>
                            <input type="password" class="form-control" name="new_password" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">确认新密码</label>
                            <input type="password" class="form-control" name="confirm_password" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                        <button type="submit" class="btn btn-primary">保存</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.bootcdn.net/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
    <script src="js/admin.js"></script>
</body>
</html>