<?php
// 防止直接访问
if (!defined('IN_ADMIN')) {
    exit('Access Denied');
}

// 获取最近的操作日志
$recentLogs = $pdo->query("
    SELECT al.*, u.username 
    FROM admin_logs al
    JOIN users u ON al.admin_id = u.id
    ORDER BY al.created_at DESC 
    LIMIT 5
")->fetchAll();

// 获取最新注册的用户
$newUsers = $pdo->query("
    SELECT * FROM users 
    ORDER BY created_at DESC 
    LIMIT 5
")->fetchAll();

// 获取今日数据
$todayStats = [
    'downloads' => $pdo->query("SELECT COUNT(*) FROM download_stats WHERE DATE(download_time) = CURDATE()")->fetchColumn(),
    'new_users' => $pdo->query("SELECT COUNT(*) FROM users WHERE DATE(created_at) = CURDATE()")->fetchColumn(),
    'vip_users' => $pdo->query("SELECT COUNT(*) FROM users WHERE is_vip = 1")->fetchColumn(),
    'total_users' => $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn()
];

// 获取VIP订单统计
$vipStats = $pdo->query("
    SELECT 
        COUNT(*) as total_orders,
        SUM(CASE WHEN status = 1 THEN 1 ELSE 0 END) as paid_orders,
        SUM(CASE WHEN status = 1 THEN amount ELSE 0 END) as total_revenue
    FROM vip_orders
")->fetch();
?>

<!-- 统计卡片 -->
<div class="row mb-4">
    <div class="col-md-3">
        <div class="stat-card text-center">
            <i class="fas fa-users"></i>
            <h3><?php echo $todayStats['total_users']; ?></h3>
            <p>总用户数</p>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card text-center">
            <i class="fas fa-crown"></i>
            <h3><?php echo $todayStats['vip_users']; ?></h3>
            <p>VIP用户数</p>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card text-center">
            <i class="fas fa-download"></i>
            <h3><?php echo $todayStats['downloads']; ?></h3>
            <p>今日下载次数</p>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card text-center">
            <i class="fas fa-user-plus"></i>
            <h3><?php echo $todayStats['new_users']; ?></h3>
            <p>今日新增用户</p>
        </div>
    </div>
</div>

<!-- 添加快捷操作按钮 -->
<div class="card mb-4">
    <div class="card-header">
        <h5>快捷操作</h5>
    </div>
    <div class="card-body">
        <div class="row g-3">
            <div class="col-md-3">
                <a href="?page=users" class="btn btn-primary w-100">
                    <i class="fas fa-users me-2"></i>用户管理
                </a>
            </div>
            <div class="col-md-3">
                <a href="?page=vip" class="btn btn-warning w-100">
                    <i class="fas fa-crown me-2"></i>VIP管理
                </a>
            </div>
            <div class="col-md-3">
                <a href="?page=content" class="btn btn-success w-100">
                    <i class="fas fa-file-alt me-2"></i>内容管理
                </a>
            </div>
            <div class="col-md-3">
                <a href="?page=logs" class="btn btn-info w-100">
                    <i class="fas fa-history me-2"></i>操作日志
                </a>
            </div>
            <div class="col-md-3">
                <a href="../" class="btn btn-secondary w-100">
                    <i class="fas fa-home me-2"></i>访问前台
                </a>
            </div>
            <div class="col-md-3">
                <button class="btn btn-danger w-100" data-bs-toggle="modal" data-bs-target="#changePasswordModal">
                    <i class="fas fa-key me-2"></i>修改密码
                </button>
            </div>
            <div class="col-md-3">
                <a href="?page=statistics" class="btn btn-primary w-100">
                    <i class="fas fa-chart-bar me-2"></i>数据统计
                </a>
            </div>
            <div class="col-md-3">
                <a href="../logout.php" class="btn btn-dark w-100">
                    <i class="fas fa-sign-out-alt me-2"></i>退出登录
                </a>
            </div>
        </div>
    </div>
</div>

<!-- VIP收入统计 -->
<div class="card mb-4">
    <div class="card-header">
        <h5>VIP收入统计</h5>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-4">
                <div class="text-center">
                    <h4><?php echo number_format($vipStats['total_orders']); ?></h4>
                    <p class="text-muted">总订单数</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="text-center">
                    <h4><?php echo number_format($vipStats['paid_orders']); ?></h4>
                    <p class="text-muted">已支付订单</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="text-center">
                    <h4>¥<?php echo number_format($vipStats['total_revenue'], 2); ?></h4>
                    <p class="text-muted">总收入</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- 最近操作日志 -->
<div class="card mb-4">
    <div class="card-header">
        <h5>最近操作日志</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>管理员</th>
                        <th>操作类型</th>
                        <th>操作详情</th>
                        <th>操作时间</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recentLogs as $log): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($log['username']); ?></td>
                            <td><?php echo htmlspecialchars($log['action_type']); ?></td>
                            <td><?php echo htmlspecialchars($log['action_detail']); ?></td>
                            <td><?php echo date('Y-m-d H:i:s', strtotime($log['created_at'])); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- 最新注册用户 -->
<div class="card">
    <div class="card-header">
        <h5>最新注册用户</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>用户名</th>
                        <th>邮箱</th>
                        <th>注册时间</th>
                        <th>VIP状态</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($newUsers as $user): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($user['username']); ?></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td><?php echo date('Y-m-d H:i:s', strtotime($user['created_at'])); ?></td>
                            <td><?php echo $user['is_vip'] ? 'VIP' : '普通用户'; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div> 