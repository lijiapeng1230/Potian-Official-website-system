<?php
// 防止直接访问
if (!defined('IN_ADMIN')) {
    exit('Access Denied');
}

// 处理套餐操作
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $action = $_POST['action'] ?? '';
        
        switch ($action) {
            case 'add_package':
                $stmt = $pdo->prepare("
                    INSERT INTO vip_packages (name, level, price, duration, description)
                    VALUES (?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $_POST['name'],
                    $_POST['level'],
                    $_POST['price'],
                    $_POST['duration'],
                    $_POST['description']
                ]);
                $success = '添加套餐成功';
                break;
                
            case 'update_package':
                $stmt = $pdo->prepare("
                    UPDATE vip_packages 
                    SET name = ?, level = ?, price = ?, duration = ?, description = ?, status = ?
                    WHERE id = ?
                ");
                $stmt->execute([
                    $_POST['name'],
                    $_POST['level'],
                    $_POST['price'],
                    $_POST['duration'],
                    $_POST['description'],
                    isset($_POST['status']) ? 1 : 0,
                    $_POST['id']
                ]);
                $success = '更新套餐成功';
                break;
                
            case 'delete_package':
                $stmt = $pdo->prepare("DELETE FROM vip_packages WHERE id = ?");
                $stmt->execute([$_POST['id']]);
                $success = '删除套餐成功';
                break;
        }
        
    } catch (Exception $e) {
        $error = '操作失败：' . $e->getMessage();
    }
}

// 获取所有VIP套餐
$packages = $pdo->query("SELECT * FROM vip_packages ORDER BY level")->fetchAll();

// 获取VIP订单统计
$orderStats = $pdo->query("
    SELECT 
        COUNT(*) as total_orders,
        SUM(CASE WHEN status = 1 THEN 1 ELSE 0 END) as paid_orders,
        SUM(CASE WHEN status = 1 THEN amount ELSE 0 END) as total_revenue
    FROM vip_orders
")->fetch();
?>

<!-- VIP统计 -->
<div class="row mb-4">
    <div class="col-md-4">
        <div class="stat-card text-center">
            <i class="fas fa-shopping-cart"></i>
            <h3><?php echo number_format($orderStats['total_orders']); ?></h3>
            <p>总订单数</p>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stat-card text-center">
            <i class="fas fa-check-circle"></i>
            <h3><?php echo number_format($orderStats['paid_orders']); ?></h3>
            <p>已支付订单</p>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stat-card text-center">
            <i class="fas fa-yen-sign"></i>
            <h3>¥<?php echo number_format($orderStats['total_revenue'], 2); ?></h3>
            <p>总收入</p>
        </div>
    </div>
</div>

<!-- VIP套餐管理 -->
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">VIP套餐管理</h5>
        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addPackageModal">
            <i class="fas fa-plus me-2"></i>添加套餐
        </button>
    </div>
    <div class="card-body">
        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>名称</th>
                        <th>等级</th>
                        <th>价格</th>
                        <th>时长(天)</th>
                        <th>状态</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($packages as $package): ?>
                    <tr>
                        <td><?php echo $package['id']; ?></td>
                        <td><?php echo htmlspecialchars($package['name']); ?></td>
                        <td><?php echo $package['level']; ?></td>
                        <td>¥<?php echo number_format($package['price'], 2); ?></td>
                        <td><?php echo $package['duration']; ?></td>
                        <td>
                            <span class="badge bg-<?php echo $package['status'] ? 'success' : 'danger'; ?>">
                                <?php echo $package['status'] ? '启用' : '禁用'; ?>
                            </span>
                        </td>
                        <td>
                            <button class="btn btn-sm btn-primary" onclick="editPackage(<?php echo htmlspecialchars(json_encode($package)); ?>)">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-sm btn-danger" onclick="deletePackage(<?php echo $package['id']; ?>)">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- 添加套餐模态框 -->
<div class="modal fade" id="addPackageModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post">
                <input type="hidden" name="action" value="add_package">
                <div class="modal-header">
                    <h5 class="modal-title">添加VIP套餐</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">套餐名称</label>
                        <input type="text" class="form-control" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">等级</label>
                        <input type="number" class="form-control" name="level" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">价格</label>
                        <input type="number" class="form-control" name="price" step="0.01" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">时长(天)</label>
                        <input type="number" class="form-control" name="duration" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">描述</label>
                        <textarea class="form-control" name="description" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                    <button type="submit" class="btn btn-primary">添加</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- 编辑套餐模态框 -->
<div class="modal fade" id="editPackageModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post">
                <input type="hidden" name="action" value="update_package">
                <input type="hidden" name="id" id="edit_id">
                <div class="modal-header">
                    <h5 class="modal-title">编辑VIP套餐</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">套餐名称</label>
                        <input type="text" class="form-control" name="name" id="edit_name" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">等级</label>
                        <input type="number" class="form-control" name="level" id="edit_level" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">价格</label>
                        <input type="number" class="form-control" name="price" id="edit_price" step="0.01" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">时长(天)</label>
                        <input type="number" class="form-control" name="duration" id="edit_duration" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">描述</label>
                        <textarea class="form-control" name="description" id="edit_description" rows="3"></textarea>
                    </div>
                    <div class="mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="status" id="edit_status" value="1">
                            <label class="form-check-label">启用套餐</label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                    <button type="submit" class="btn btn-primary">保存</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function editPackage(packageId) {
    // 通过 AJAX 获取套餐信息
    fetch(`api/packages.php?action=get&id=${packageId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const package = data.package;
                // 填充表单
                document.getElementById('edit_id').value = package.id;
                document.getElementById('edit_name').value = package.name;
                document.getElementById('edit_level').value = package.level;
                document.getElementById('edit_price').value = package.price;
                document.getElementById('edit_duration').value = package.duration;
                document.getElementById('edit_description').value = package.description;
                document.getElementById('edit_status').checked = package.status == 1;
                
                // 显示模态框
                new bootstrap.Modal(document.getElementById('editPackageModal')).show();
            } else {
                alert('获取套餐信息失败');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('系统错误，请稍后重试');
        });
}

function deletePackage(id) {
    if (confirm('确定要删除这个套餐吗？')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type="hidden" name="action" value="delete_package">
            <input type="hidden" name="id" value="${id}">
        `;
        document.body.appendChild(form);
        form.submit();
    }
}
</script>

<script>
function editPackage(package) {
    document.getElementById('edit_id').value = package.id;
    document.getElementById('edit_name').value = package.name;
    document.getElementById('edit_level').value = package.level;
    document.getElementById('edit_price').value = package.price;
    document.getElementById('edit_duration').value = package.duration;
    document.getElementById('edit_description').value = package.description;
    document.getElementById('edit_status').checked = package.status == 1;
    
    new bootstrap.Modal(document.getElementById('editPackageModal')).show();
}

function deletePackage(id) {
    if (confirm('确定要删除这个套餐吗？')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type="hidden" name="action" value="delete_package">
            <input type="hidden" name="id" value="${id}">
        `;
        document.body.appendChild(form);
        form.submit();
    }
}
</script> 