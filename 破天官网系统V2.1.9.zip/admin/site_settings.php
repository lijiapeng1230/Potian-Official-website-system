<?php
// 防止直接访问
if (!defined('IN_ADMIN')) {
    exit('Access Denied');
}

// 处理设置更新
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $pdo->beginTransaction();
        
        $settings = [
            'site_name' => $_POST['site_name'] ?? '',
            'site_description' => $_POST['site_description'] ?? '',
            'site_keywords' => $_POST['site_keywords'] ?? '',
            'site_icp' => $_POST['site_icp'] ?? '',
            'site_copyright' => $_POST['site_copyright'] ?? '',
            'site_start_time' => $_POST['site_start_time'] ?? '',
            'contact_skype' => $_POST['contact_skype'] ?? '',
            'contact_qq' => $_POST['contact_qq'] ?? '',
            'contact_email' => $_POST['contact_email'] ?? '',
            'contact_address' => $_POST['contact_address'] ?? ''
        ];

        $stmt = $pdo->prepare("
            INSERT INTO settings (setting_key, setting_value) 
            VALUES (?, ?) 
            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
        ");

        foreach ($settings as $key => $value) {
            $stmt->execute([$key, $value]);
        }

        $pdo->commit();
        $auth->logAdminAction('update_settings', '更新网站设置');
        $success = '设置已更新';

    } catch (Exception $e) {
        $pdo->rollBack();
        $error = '更新失败：' . $e->getMessage();
    }
}

// 获取当前设置
$settings = [];
$stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
while ($row = $stmt->fetch()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}
?>

<div class="card">
    <div class="card-header">
        <h5 class="mb-0">网站信息设置</h5>
    </div>
    <div class="card-body">
        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="post">
            <div class="mb-3">
                <label class="form-label">网站名称</label>
                <input type="text" class="form-control" name="site_name" 
                       value="<?php echo htmlspecialchars($settings['site_name'] ?? ''); ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">网站描述</label>
                <textarea class="form-control" name="site_description" rows="3"
                    ><?php echo htmlspecialchars($settings['site_description'] ?? ''); ?></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">网站关键词</label>
                <input type="text" class="form-control" name="site_keywords"
                       value="<?php echo htmlspecialchars($settings['site_keywords'] ?? ''); ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">ICP备案号</label>
                <input type="text" class="form-control" name="site_icp"
                       value="<?php echo htmlspecialchars($settings['site_icp'] ?? ''); ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">版权信息</label>
                <input type="text" class="form-control" name="site_copyright"
                       value="<?php echo htmlspecialchars($settings['site_copyright'] ?? ''); ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">网站开始运行时间</label>
                <input type="datetime-local" class="form-control" name="site_start_time"
                       value="<?php echo htmlspecialchars($settings['site_start_time'] ?? ''); ?>">
            </div>

            <h5 class="mt-4 mb-3">联系方式设置</h5>

            <div class="mb-3">
                <label class="form-label">Skype联系方式</label>
                <input type="text" class="form-control" name="contact_skype"
                       value="<?php echo htmlspecialchars($settings['contact_skype'] ?? ''); ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">QQ联系方式</label>
                <input type="text" class="form-control" name="contact_qq"
                       value="<?php echo htmlspecialchars($settings['contact_qq'] ?? ''); ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">联系邮箱</label>
                <input type="email" class="form-control" name="contact_email"
                       value="<?php echo htmlspecialchars($settings['contact_email'] ?? ''); ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">联系地址</label>
                <input type="text" class="form-control" name="contact_address"
                       value="<?php echo htmlspecialchars($settings['contact_address'] ?? ''); ?>">
            </div>

            <button type="submit" class="btn btn-primary">
                <i class="fas fa-save me-2"></i>保存设置
            </button>
        </form>
    </div>
</div> 