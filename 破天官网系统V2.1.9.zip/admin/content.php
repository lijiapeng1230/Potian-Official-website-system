<?php
// 防止直接访问
if (!defined('IN_ADMIN')) {
    exit('Access Denied');
}

// 处理内容更新
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $pdo->beginTransaction();
        
        if (isset($_POST['vip_content'])) {
            $vipContent = [];
            foreach ($_POST['vip_content'] as $content) {
                if (!empty($content['title'])) {
                    $vipContent[] = [
                        'title' => $content['title'],
                        'content' => $content['content'] ?? '',
                        'type' => $content['type'] ?? 'text',
                        'download_url' => $content['download_url'] ?? '',
                        'image_url' => $content['image_url'] ?? '',
                        'visible_level' => (int)($content['visible_level'] ?? 1)
                    ];
                }
            }
            
            $stmt = $pdo->prepare("
                INSERT INTO settings (setting_key, setting_value, setting_description) 
                VALUES ('vip_content', ?, 'VIP专属内容') 
                ON DUPLICATE KEY UPDATE setting_value = ?
            ");
            $jsonContent = json_encode($vipContent, JSON_UNESCAPED_UNICODE);
            $stmt->execute([$jsonContent, $jsonContent]);
        }
        
        $pdo->commit();
        $auth->logAdminAction('update_content', '更新VIP内容');
        $success = '内容更新成功';
        
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = '更新失败：' . $e->getMessage();
    }
}

// 获取当前VIP内容
$stmt = $pdo->query("SELECT setting_value FROM settings WHERE setting_key = 'vip_content'");
$vipContent = $stmt->fetchColumn();
$vipContent = $vipContent ? json_decode($vipContent, true) : [];
?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">VIP内容管理</h5>
        <button type="button" class="btn btn-primary btn-sm" onclick="addVipContent()">
            <i class="fas fa-plus me-2"></i>添加内容
        </button>
    </div>
    <div class="card-body">
        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="post" id="vipContentForm">
            <div id="vipContentContainer">
                <?php foreach ($vipContent as $index => $content): ?>
                    <div class="vip-content-item border rounded p-3 mb-3">
                        <div class="mb-3">
                            <label class="form-label">标题</label>
                            <input type="text" class="form-control" 
                                   name="vip_content[<?php echo $index; ?>][title]"
                                   value="<?php echo htmlspecialchars($content['title']); ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">内容类型</label>
                            <select class="form-select" name="vip_content[<?php echo $index; ?>][type]"
                                    onchange="toggleContentFields(this)">
                                <option value="text" <?php echo ($content['type'] ?? 'text') === 'text' ? 'selected' : ''; ?>>文本</option>
                                <option value="download" <?php echo ($content['type'] ?? '') === 'download' ? 'selected' : ''; ?>>下载</option>
                                <option value="image" <?php echo ($content['type'] ?? '') === 'image' ? 'selected' : ''; ?>>图片</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">内容</label>
                            <textarea class="form-control" 
                                    name="vip_content[<?php echo $index; ?>][content]" 
                                    rows="3"><?php echo htmlspecialchars($content['content'] ?? ''); ?></textarea>
                        </div>
                        
                        <div class="mb-3 download-field" style="display: <?php echo ($content['type'] ?? '') === 'download' ? 'block' : 'none'; ?>">
                            <label class="form-label">下载链接</label>
                            <input type="url" class="form-control" 
                                   name="vip_content[<?php echo $index; ?>][download_url]"
                                   value="<?php echo htmlspecialchars($content['download_url'] ?? ''); ?>">
                        </div>
                        
                        <div class="mb-3 image-field" style="display: <?php echo ($content['type'] ?? '') === 'image' ? 'block' : 'none'; ?>">
                            <label class="form-label">图片链接</label>
                            <input type="url" class="form-control" 
                                   name="vip_content[<?php echo $index; ?>][image_url]"
                                   value="<?php echo htmlspecialchars($content['image_url'] ?? ''); ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">可见VIP等级</label>
                            <select class="form-select" name="vip_content[<?php echo $index; ?>][visible_level]">
                                <option value="1" <?php echo ($content['visible_level'] ?? 1) === 1 ? 'selected' : ''; ?>>VIP1</option>
                                <option value="2" <?php echo ($content['visible_level'] ?? 1) === 2 ? 'selected' : ''; ?>>VIP2</option>
                                <option value="3" <?php echo ($content['visible_level'] ?? 1) === 3 ? 'selected' : ''; ?>>VIP3</option>
                            </select>
                        </div>
                        
                        <button type="button" class="btn btn-danger btn-sm" onclick="removeVipContent(this)">
                            <i class="fas fa-trash me-2"></i>删除
                        </button>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-save me-2"></i>保存所有内容
            </button>
        </form>
    </div>
</div>

<script>
function addVipContent() {
    const container = document.getElementById('vipContentContainer');
    const index = container.children.length;
    const template = `
        <div class="vip-content-item border rounded p-3 mb-3">
            <div class="mb-3">
                <label class="form-label">标题</label>
                <input type="text" class="form-control" name="vip_content[${index}][title]" required>
            </div>
            
            <div class="mb-3">
                <label class="form-label">内容类型</label>
                <select class="form-select" name="vip_content[${index}][type]" onchange="toggleContentFields(this)">
                    <option value="text">文本</option>
                    <option value="download">下载</option>
                    <option value="image">图片</option>
                </select>
            </div>
            
            <div class="mb-3">
                <label class="form-label">内容</label>
                <textarea class="form-control" name="vip_content[${index}][content]" rows="3"></textarea>
            </div>
            
            <div class="mb-3 download-field" style="display: none;">
                <label class="form-label">下载链接</label>
                <input type="url" class="form-control" name="vip_content[${index}][download_url]">
            </div>
            
            <div class="mb-3 image-field" style="display: none;">
                <label class="form-label">图片链接</label>
                <input type="url" class="form-control" name="vip_content[${index}][image_url]">
            </div>
            
            <div class="mb-3">
                <label class="form-label">可见VIP等级</label>
                <select class="form-select" name="vip_content[${index}][visible_level]">
                    <option value="1">VIP1</option>
                    <option value="2">VIP2</option>
                    <option value="3">VIP3</option>
                </select>
            </div>
            
            <button type="button" class="btn btn-danger btn-sm" onclick="removeVipContent(this)">
                <i class="fas fa-trash me-2"></i>删除
            </button>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', template);
}

function removeVipContent(button) {
    if (confirm('确定要删除这个内容吗？')) {
        button.closest('.vip-content-item').remove();
    }
}

function toggleContentFields(select) {
    const item = select.closest('.vip-content-item');
    const downloadField = item.querySelector('.download-field');
    const imageField = item.querySelector('.image-field');
    
    downloadField.style.display = select.value === 'download' ? 'block' : 'none';
    imageField.style.display = select.value === 'image' ? 'block' : 'none';
}
</script> 