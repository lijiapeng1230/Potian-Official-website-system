<?php
// 防止直接访问
if (!defined('IN_ADMIN')) {
    exit('Access Denied');
}

// 初始化统计变量
$totalUsers = 0;
$activeCount = 0;
$vipCount = 0;
$adminCount = 0;

// 获取筛选参数
$status = isset($_GET['status']) ? $_GET['status'] : '';
$is_vip = isset($_GET['is_vip']) ? $_GET['is_vip'] : '';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

try {
    // 获取统计数据
    $totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $activeCount = $pdo->query("SELECT COUNT(*) FROM users WHERE status = 1")->fetchColumn();
    $vipCount = $pdo->query("SELECT COUNT(*) FROM users WHERE is_vip = 1")->fetchColumn();
    $adminCount = $pdo->query("SELECT COUNT(*) FROM users WHERE is_admin = 1")->fetchColumn();

    // 构建用户列表查询
    $query = "SELECT * FROM users WHERE 1=1";
    $params = [];

    if ($status !== '') {
        $query .= " AND status = ?";
        $params[] = $status;
    }

    if ($is_vip !== '') {
        $query .= " AND is_vip = ?";
        $params[] = $is_vip;
    }

    if ($search) {
        $query .= " AND (username LIKE ? OR email LIKE ?)";
        $params[] = "%$search%";
        $params[] = "%$search%";
    }

    $query .= " ORDER BY created_at DESC";

    // 执行查询
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $users = $stmt->fetchAll();

} catch (PDOException $e) {
    error_log("Users page error: " . $e->getMessage());
    $error = "获取用户数据失败";
    $users = [];
}
?>

<!-- 统计卡片 -->
<div class="row mb-4">
    <div class="col-md-3">
        <div class="card bg-primary text-white">
            <div class="card-body text-center">
                <h3 class="display-4"><?php echo $totalUsers; ?></h3>
                <p class="mb-0">总用户数</p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-success text-white">
            <div class="card-body text-center">
                <h3 class="display-4"><?php echo $activeCount; ?></h3>
                <p class="mb-0">活跃用户</p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-warning text-dark">
            <div class="card-body text-center">
                <h3 class="display-4"><?php echo $vipCount; ?></h3>
                <p class="mb-0">VIP用户</p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-info text-white">
            <div class="card-body text-center">
                <h3 class="display-4"><?php echo $adminCount; ?></h3>
                <p class="mb-0">管理员</p>
            </div>
        </div>
    </div>
</div>

<!-- 用户列表 -->
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">用户管理</h5>
        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addUserModal">
            <i class="fas fa-user-plus me-2"></i>添加用户
        </button>
    </div>
    <div class="card-body">
        <!-- 筛选表单 -->
        <form method="get" class="mb-4">
            <input type="hidden" name="page" value="users">
            <div class="row g-3">
                <div class="col-md-3">
                    <select name="status" class="form-select">
                        <option value="">所有状态</option>
                        <option value="1" <?php echo $status === '1' ? 'selected' : ''; ?>>正常</option>
                        <option value="0" <?php echo $status === '0' ? 'selected' : ''; ?>>禁用</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="is_vip" class="form-select">
                        <option value="">所有用户</option>
                        <option value="1" <?php echo $is_vip === '1' ? 'selected' : ''; ?>>VIP用户</option>
                        <option value="0" <?php echo $is_vip === '0' ? 'selected' : ''; ?>>普通用户</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <input type="text" name="search" class="form-control" placeholder="搜索用户名或邮箱" 
                           value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">筛选</button>
                </div>
            </div>
        </form>

        <!-- 用户列表表格 -->
        <div class="table-responsive">
            <table class="table table-hover">
                <thead class="table-light">
                    <tr>
                        <th>ID</th>
                        <th>用户名</th>
                        <th>邮箱</th>
                        <th>角色</th>
                        <th>VIP等级</th>
                        <th>状态</th>
                        <th>注册时间</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?php echo $user['id']; ?></td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <img src="https://www.gravatar.com/avatar/<?php echo md5($user['email']); ?>?s=32&d=mp" 
                                         class="rounded-circle me-2" width="32" height="32">
                                    <?php echo htmlspecialchars($user['username']); ?>
                                </div>
                            </td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td>
                                <?php if ($user['is_admin']): ?>
                                    <span class="badge bg-danger">管理员</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">普通用户</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($user['is_vip']): ?>
                                    <?php
                                    $vipBadges = [
                                        1 => '<span class="badge bg-secondary">青铜VIP</span>',
                                        2 => '<span class="badge bg-light text-dark border">白银VIP</span>',
                                        3 => '<span class="badge bg-warning text-dark">黄金VIP</span>'
                                    ];
                                    echo $vipBadges[$user['vip_level']] ?? '';
                                    ?>
                                <?php else: ?>
                                    <span class="badge bg-light text-dark border">普通会员</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge bg-<?php echo $user['status'] ? 'success' : 'danger'; ?>">
                                    <?php echo $user['status'] ? '正常' : '禁用'; ?>
                                </span>
                            </td>
                            <td><?php echo date('Y-m-d H:i', strtotime($user['created_at'])); ?></td>
                            <td>
                                <div class="btn-group">
                                    <button class="btn btn-sm btn-primary" onclick="editUser(<?php echo $user['id']; ?>)">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-danger" onclick="deleteUser(<?php echo $user['id']; ?>)">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div> 