<?php
require_once '../includes/db.php';
require_once '../classes/Auth.php';
require_once '../classes/Captcha.php';

$pdo = Database::getInstance();
$auth = new Auth($pdo);

// 如果已经登录，直接跳转到后台首页
if ($auth->isLoggedIn() && $auth->isAdmin()) {
    header('Location: index.php');
    exit;
}

// 处理登录请求
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $captcha = $_POST['captcha'] ?? '';

    if (!Captcha::verify($captcha)) {
        $error = '验证码错误';
    } elseif ($auth->adminLogin($username, $password)) {
        // 记录管理员登录日志
        $auth->logAdminAction('login', '管理员登录');
        header('Location: index.php');
        exit;
    } else {
        $error = '用户名或密码错误';
    }
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理员登录 - 破天星辰科技网络</title>
    <link href="https://cdn.bootcdn.net/ajax/libs/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.bootcdn.net/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #010d15;
            background-image: url('https://app.potiankeji.top/cdn/img/background4.webp');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-container {
            width: 100%;
            max-width: 400px;
            padding: 20px;
        }

        .card {
            background-color: rgba(16, 35, 42, 0.9);
            backdrop-filter: blur(10px);
            border: none;
            border-radius: 15px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }

        .card-header {
            background-color: rgba(2, 11, 12, 0.8);
            border-bottom: 1px solid #0b666a;
            border-radius: 15px 15px 0 0;
            padding: 20px;
            text-align: center;
        }

        .card-header h3 {
            color: #fff;
            margin: 0;
            font-size: 1.8em;
        }

        .card-body {
            padding: 30px;
        }

        .form-control {
            background-color: rgba(2, 11, 12, 0.8);
            border: 1px solid #0b666a;
            color: #fff;
            padding: 12px;
        }

        .form-control:focus {
            background-color: rgba(2, 11, 12, 0.9);
            border-color: #7FFFD4;
            color: #fff;
        }

        .btn-primary {
            background-color: #0b666a;
            border: none;
            padding: 12px;
            width: 100%;
        }

        .btn-primary:hover {
            background-color: #0c7075;
        }

        .alert {
            background-color: rgba(139, 0, 0, 0.9);
            border: none;
            color: #fff;
        }

        .form-label {
            color: #7FFFD4;
        }

        .captcha-container {
            display: flex;
            gap: 10px;
        }

        .captcha-input {
            flex: 1;
        }

        .captcha-image {
            background: #fff;
            padding: 5px;
            border-radius: 4px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="card">
            <div class="card-header">
                <h3>管理员登录</h3>
            </div>
            <div class="card-body">
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger mb-4">
                        <i class="fas fa-exclamation-circle me-2"></i><?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>

                <form method="post">
                    <div class="mb-4">
                        <label class="form-label">用户名</label>
                        <div class="input-group">
                            <span class="input-group-text bg-dark border-0 text-light">
                                <i class="fas fa-user"></i>
                            </span>
                            <input type="text" class="form-control" name="username" required>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">密码</label>
                        <div class="input-group">
                            <span class="input-group-text bg-dark border-0 text-light">
                                <i class="fas fa-lock"></i>
                            </span>
                            <input type="password" class="form-control" name="password" required>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">验证码</label>
                        <div class="captcha-container">
                            <div class="input-group captcha-input">
                                <span class="input-group-text bg-dark border-0 text-light">
                                    <i class="fas fa-shield-alt"></i>
                                </span>
                                <input type="text" class="form-control" name="captcha" required>
                            </div>
                            <img src="../captcha.php" class="captcha-image" onclick="this.src='../captcha.php?'+Math.random()" title="点击刷新">
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-sign-in-alt me-2"></i>登录
                    </button>
                </form>
            </div>
        </div>
    </div>
</body>
</html> 