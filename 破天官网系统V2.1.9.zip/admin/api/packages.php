<?php
require_once '../../includes/db.php';
require_once '../../classes/Auth.php';

header('Content-Type: application/json');

try {
    $pdo = Database::getInstance();
    $auth = new Auth($pdo);

    if (!$auth->isLoggedIn() || !$auth->isAdmin()) {
        throw new Exception('无权限访问');
    }

    $action = $_GET['action'] ?? '';

    switch ($action) {
        case 'get':
            $id = $_GET['id'] ?? 0;
            $stmt = $pdo->prepare("SELECT * FROM vip_packages WHERE id = ?");
            $stmt->execute([$id]);
            $package = $stmt->fetch();
            
            if ($package) {
                echo json_encode([
                    'success' => true,
                    'package' => $package
                ]);
            } else {
                throw new Exception('套餐不存在');
            }
            break;

        default:
            throw new Exception('未知操作');
    }

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
} 