<?php
require_once '../../includes/db.php';
require_once '../../classes/Auth.php';

header('Content-Type: application/json');

try {
    $pdo = Database::getInstance();
    $auth = new Auth($pdo);

    if (!$auth->isLoggedIn() || !$auth->isAdmin()) {
        throw new Exception('无权限访问');
    }

    $action = $_GET['action'] ?? '';

    switch ($action) {
        case 'add':
            // 添加用户
            $stmt = $pdo->prepare("
                INSERT INTO users (username, email, password, is_admin, is_vip, status)
                VALUES (?, ?, ?, ?, ?, 1)
            ");
            $stmt->execute([
                $_POST['username'],
                $_POST['email'],
                password_hash($_POST['password'], PASSWORD_DEFAULT),
                isset($_POST['is_admin']) ? 1 : 0,
                isset($_POST['is_vip']) ? 1 : 0
            ]);
            echo json_encode(['success' => true]);
            break;

        case 'get':
            // 获取用户信息
            $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
            $stmt->execute([$_GET['id']]);
            $user = $stmt->fetch();
            echo json_encode(['success' => true, 'user' => $user]);
            break;

        case 'update':
            // 更新用户信息
            $sql = "UPDATE users SET 
                    username = ?,
                    email = ?,
                    is_admin = ?,
                    is_vip = ?,
                    status = ?";
            $params = [
                $_POST['username'],
                $_POST['email'],
                isset($_POST['is_admin']) ? 1 : 0,
                isset($_POST['is_vip']) ? 1 : 0,
                isset($_POST['status']) ? 1 : 0,
                $_POST['id']
            ];

            // 如果提供了新密码
            if (!empty($_POST['password'])) {
                $sql .= ", password = ?";
                array_unshift($params, password_hash($_POST['password'], PASSWORD_DEFAULT));
            }

            $sql .= " WHERE id = ?";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            echo json_encode(['success' => true]);
            break;

        case 'delete':
            // 删除用户
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$_GET['id']]);
            echo json_encode(['success' => true]);
            break;

        default:
            throw new Exception('未知操作');
    }

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
} 