// 用户管理相关函数
function editUser(userId) {
    fetch(`api/users.php?action=get&id=${userId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const user = data.user;
                document.getElementById('edit_id').value = user.id;
                document.getElementById('edit_username').value = user.username;
                document.getElementById('edit_email').value = user.email;
                document.getElementById('edit_is_admin').checked = user.is_admin == 1;
                document.getElementById('edit_is_vip').checked = user.is_vip == 1;
                document.getElementById('edit_status').checked = user.status == 1;
                
                new bootstrap.Modal(document.getElementById('editUserModal')).show();
            }
        });
}

function deleteUser(userId) {
    if (confirm('确定要删除这个用户吗？')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type="hidden" name="action" value="delete_user">
            <input type="hidden" name="id" value="${userId}">
        `;
        document.body.appendChild(form);
        form.submit();
    }
}

// 内容管理相关函数
function editContent(contentId) {
    fetch(`api/content.php?action=get&id=${contentId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const content = data.content;
                document.getElementById('edit_content_id').value = content.id;
                document.getElementById('edit_title').value = content.title;
                document.getElementById('edit_content').value = content.content;
                document.getElementById('edit_type').value = content.type;
                
                new bootstrap.Modal(document.getElementById('editContentModal')).show();
            }
        });
}

function deleteContent(contentId) {
    if (confirm('确定要删除这个内容吗？')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type="hidden" name="action" value="delete_content">
            <input type="hidden" name="id" value="${contentId}">
        `;
        document.body.appendChild(form);
        form.submit();
    }
}

// VIP管理相关函数
function editPackage(packageId) {
    fetch(`api/packages.php?action=get&id=${packageId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const package = data.package;
                document.getElementById('edit_package_id').value = package.id;
                document.getElementById('edit_name').value = package.name;
                document.getElementById('edit_price').value = package.price;
                document.getElementById('edit_duration').value = package.duration;
                document.getElementById('edit_description').value = package.description;
                
                new bootstrap.Modal(document.getElementById('editPackageModal')).show();
            }
        });
}

function deletePackage(packageId) {
    if (confirm('确定要删除这个套餐吗？')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type="hidden" name="action" value="delete_package">
            <input type="hidden" name="id" value="${packageId}">
        `;
        document.body.appendChild(form);
        form.submit();
    }
}

// 通用函数
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 end-0 m-3`;
    toast.style.zIndex = '1050';
    toast.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    document.body.appendChild(toast);
    setTimeout(() => {
        toast.remove();
    }, 3000);
} 